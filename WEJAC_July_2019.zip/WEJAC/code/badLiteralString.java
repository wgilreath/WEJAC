public final class badLiteralString{

  public final static void main(String[]){
    System.out.println("Hello, World!!!');
    System.exit(0);
  }
}
