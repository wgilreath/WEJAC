public final class HelloWorldBad{

  public final static void main(String[] args){
    System.out.println("Hello, World!!!');
    System.exit(0);
  }
}
